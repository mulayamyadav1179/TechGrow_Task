// Array of quotes
const quotes = [
  { text: "The best way to predict your future is to create it.", author: "Peter Drucker" },
  { text: "Life is what happens when you’re busy making other plans.", author: "John Lennon" },
  { text: "Get busy living or get busy dying.", author: "Stephen King" },
  { text: "You only live once, but if you do it right, once is enough.", author: "Mae West" },
  { text: "In the end, we only regret the chances we didn’t take.", author: "Lewis Carroll" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
];

// Function to generate a random quote
function generateQuote() {
  const randomIndex = Math.floor(Math.random() * quotes.length);
  const quote = quotes[randomIndex];
  document.getElementById('quote').innerText = `"${quote.text}"`;
  document.getElementById('author').innerText = `- ${quote.author}`;
}

// Event listener for the button
document.getElementById('generate-quote').addEventListener('click', generateQuote);

// Generate a quote on initial load
generateQuote();
