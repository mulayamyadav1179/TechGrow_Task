document.querySelector('form').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission
  alert('Thank you for reaching out to us!');
});

